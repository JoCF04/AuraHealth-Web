package com.aurahealth.api.auradtos;

import lombok.Data;
import java.time.LocalDate;
import java.time.LocalTime;

/**
 * DTO de salida para un recordatorio.
 * Incluye isDone para que el frontend actualice el estado del checkbox.
 */
@Data
public class ReminderResponseDTO {

    private Long   id;
    private Long   userId;
    private String title;
    private String reminderType;
    private LocalDate scheduledDate;
    private LocalTime scheduledTime;
    private Boolean   isDone;
}
