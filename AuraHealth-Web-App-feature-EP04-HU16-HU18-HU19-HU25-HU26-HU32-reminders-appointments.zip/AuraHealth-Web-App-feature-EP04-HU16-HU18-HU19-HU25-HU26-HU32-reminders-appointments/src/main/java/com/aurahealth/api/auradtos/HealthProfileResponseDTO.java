package com.aurahealth.api.auradtos;

import lombok.*;
import java.math.BigDecimal;

/**
 * DTO de salida para el perfil de salud del usuario (EP03).
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class HealthProfileResponseDTO {

    private Long userId;
    private String bloodType;
    private String bloodPressure;
    private BigDecimal glucoseLevel;
    private BigDecimal cholesterolLevel;
    private String allergies;
    private BigDecimal weightKg;
    private BigDecimal heightCm;
}
