package com.aurahealth.api.auradtos;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import lombok.Data;

/**
 * DTO de entrada para crear o actualizar un recordatorio.
 * Usado en POST y PUT /api/v1/users/{userId}/reminders.
 */
@Data
public class ReminderRequestDTO {

    @NotBlank(message = "El título del recordatorio es obligatorio")
    private String title;

    // Valores aceptados definidos en el CHECK constraint de la BD
    @NotBlank(message = "El tipo de recordatorio es obligatorio")
    @Pattern(
        regexp  = "medical|medicine|exam|vaccine",
        message = "Tipo inválido. Valores aceptados: medical, medicine, exam, vaccine"
    )
    private String reminderType;

    // Formato esperado: "YYYY-MM-DD"  (el Service lo parsea a LocalDate)
    @NotNull(message = "La fecha programada es obligatoria")
    private String scheduledDate;

    // Formato esperado: "HH:mm"  (opcional)
    private String scheduledTime;
}
