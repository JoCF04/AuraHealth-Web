package com.aurahealth.api.auracontrollers;

import com.aurahealth.api.auradtos.*;
import com.aurahealth.api.auraservices.UserService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1")
@Tag(name = "Users & Health Profiles",
     description = "EP03 — Gestión de cuentas de usuario y datos de salud personales")
public class UserController {

    private final UserService userService;

    public UserController(UserService userService) {
        this.userService = userService;
    }

    // ----------------------------------------------------------------
    //  HU01 — Registro de usuario
    //  POST /api/v1/users
    // ----------------------------------------------------------------

    @Operation(
        summary     = "HU01 — Registrar nuevo usuario",
        description = "Crea una cuenta nueva en la plataforma AuraHealth. "
                    + "El correo electrónico debe ser único. Devuelve el usuario creado con su id.")
    @ApiResponses({
        @ApiResponse(responseCode = "201", description = "Usuario registrado exitosamente"),
        @ApiResponse(responseCode = "400", description = "Datos de entrada inválidos (campos obligatorios vacíos o formato incorrecto)"),
        @ApiResponse(responseCode = "409", description = "El correo electrónico ya está registrado")
    })
    @PostMapping("/users")
    public ResponseEntity<UserResponseDTO> registrarUsuario(
            @Valid @RequestBody UserRegistrationRequestDTO requestDTO) {
        UserResponseDTO response = userService.registrarUsuario(requestDTO);
        return ResponseEntity.status(HttpStatus.CREATED).body(response);
    }

    // ----------------------------------------------------------------
    //  HU02 — Visualización de información personal y médica
    //  GET /api/v1/users/{id}
    // ----------------------------------------------------------------

    @Operation(
        summary     = "HU02 — Obtener perfil completo del usuario",
        description = "Retorna los datos personales del usuario y su perfil de salud asociado "
                    + "(grupo sanguíneo, glucosa, peso, talla, etc.). "
                    + "El campo healthProfile será null si el usuario aún no lo completó.")
    @ApiResponses({
        @ApiResponse(responseCode = "200", description = "Información del usuario obtenida exitosamente"),
        @ApiResponse(responseCode = "404", description = "Usuario no encontrado")
    })
    @GetMapping("/users/{id}")
    public ResponseEntity<UserResponseDTO> obtenerUsuario(
            @Parameter(description = "ID del usuario", example = "1", required = true)
            @PathVariable Long id) {
        return ResponseEntity.ok(userService.obtenerUsuarioPorId(id));
    }

    // ----------------------------------------------------------------
    //  HU12 / HU20 — Actualización de perfil de salud
    //  PUT /api/v1/users/{userId}/health-profile
    // ----------------------------------------------------------------

    @Operation(
        summary     = "HU12 / HU20 — Actualizar perfil de salud",
        description = "Crea o actualiza (upsert) el perfil de salud del usuario: "
                    + "peso, talla, tipo de sangre, niveles de glucosa y colesterol, "
                    + "presión arterial y alergias. Si el perfil no existía, se crea automáticamente.")
    @ApiResponses({
        @ApiResponse(responseCode = "200", description = "Perfil de salud actualizado exitosamente"),
        @ApiResponse(responseCode = "404", description = "Usuario no encontrado")
    })
    @PutMapping("/users/{userId}/health-profile")
    public ResponseEntity<HealthProfileResponseDTO> actualizarPerfilDeSalud(
            @Parameter(description = "ID del usuario propietario del perfil", example = "1", required = true)
            @PathVariable Long userId,
            @RequestBody HealthProfileRequestDTO requestDTO) {
        return ResponseEntity.ok(userService.actualizarPerfilDeSalud(userId, requestDTO));
    }
}
