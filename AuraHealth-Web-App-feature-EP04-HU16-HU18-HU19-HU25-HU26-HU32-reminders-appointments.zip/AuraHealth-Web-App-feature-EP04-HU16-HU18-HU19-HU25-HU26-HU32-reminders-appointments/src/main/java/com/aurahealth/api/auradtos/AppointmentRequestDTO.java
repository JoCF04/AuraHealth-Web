package com.aurahealth.api.auradtos;

import jakarta.validation.constraints.NotNull;
import lombok.Data;

/**
 * DTO de entrada para agendar o actualizar una cita médica.
 * Usado en POST y PUT /api/v1/users/{userId}/appointments.
 */
@Data
public class AppointmentRequestDTO {

    private String doctorName;

    private String specialty;

    private String clinicName;

    // Formato esperado: "YYYY-MM-DD"
    @NotNull(message = "La fecha de la cita es obligatoria")
    private String appointmentDate;

    // Formato esperado: "HH:mm"  (opcional)
    private String appointmentTime;

    private String notes;

    private Boolean isConfirmed = Boolean.FALSE;
}
