package com.aurahealth.api.auradtos;

import lombok.Data;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.LocalDateTime;

/**
 * DTO de salida para una cita médica agendada.
 * El frontend usa appointmentDate + appointmentTime para mostrar
 * el bloque de la cita en el calendario del módulo EP04.
 */
@Data
public class AppointmentResponseDTO {

    private Long   id;
    private Long   userId;
    private String doctorName;
    private String specialty;
    private String clinicName;
    private LocalDate     appointmentDate;
    private LocalTime     appointmentTime;
    private String        notes;
    private Boolean       isConfirmed;
    private LocalDateTime createdAt;
}
