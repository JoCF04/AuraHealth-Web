package com.aurahealth.api.auraentities;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDate;
import java.time.LocalTime;

/**
 * Entidad que representa un recordatorio de salud del usuario.
 * Cubre todos los tipos definidos en la tabla: medical, medicine, exam, vaccine.
 * Corresponde a lo que el diseño de Figma llama "MedicationReminder".
 *
 * HUs cubiertas: HU16 (crear), HU18 (listar/filtrar), HU19 (marcar completado), HU32 (vencidos)
 */
@Entity
@Table(name = "reminders")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Reminder {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    // Muchos recordatorios pertenecen a un usuario
    @ToString.Exclude
    @EqualsAndHashCode.Exclude
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id", nullable = false)
    private User user;

    // Título visible en la tarjeta del recordatorio (ej: "Tomar Ibuprofeno")
    @Column(nullable = false)
    private String title;

    // Tipo: medical | medicine | exam | vaccine  (CHECK constraint en BD)
    @Column(name = "reminder_type", nullable = false, length = 50)
    private String reminderType;

    // Fecha programada para el recordatorio
    @Column(name = "scheduled_date")
    private LocalDate scheduledDate;

    // Hora programada (opcional)
    @Column(name = "scheduled_time")
    private LocalTime scheduledTime;

    // HU19 — el usuario puede marcar el recordatorio como completado
    @Column(name = "is_done", nullable = false)
    private Boolean isDone = Boolean.FALSE;
}
