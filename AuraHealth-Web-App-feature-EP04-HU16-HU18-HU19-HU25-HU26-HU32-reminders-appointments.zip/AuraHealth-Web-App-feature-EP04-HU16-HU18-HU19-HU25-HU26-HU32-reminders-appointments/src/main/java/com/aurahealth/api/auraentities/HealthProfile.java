package com.aurahealth.api.auraentities;

import jakarta.persistence.*;
import lombok.*;
import java.math.BigDecimal;

/**
 * Relación 1:1 con User usando shared primary key.
 * user_id es a la vez PK de health_profiles y FK hacia users.id.
 * @MapsId vincula el @Id de esta entidad al id del User relacionado.
 */
@Entity
@Table(name = "health_profiles")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class HealthProfile {

    @Id
    @Column(name = "user_id")
    private Long userId;

    @ToString.Exclude
    @EqualsAndHashCode.Exclude
    @OneToOne(fetch = FetchType.LAZY)
    @MapsId
    @JoinColumn(name = "user_id")
    private User user;

    @Column(name = "blood_type", length = 10)
    private String bloodType;

    @Column(name = "blood_pressure", length = 20)
    private String bloodPressure;

    @Column(name = "glucose_level", precision = 6, scale = 2)
    private BigDecimal glucoseLevel;

    @Column(name = "cholesterol_level", precision = 6, scale = 2)
    private BigDecimal cholesterolLevel;

    @Column(name = "allergies", columnDefinition = "TEXT")
    private String allergies;

    @Column(name = "weight_kg", precision = 5, scale = 2)
    private BigDecimal weightKg;

    @Column(name = "height_cm", precision = 5, scale = 2)
    private BigDecimal heightCm;
}
