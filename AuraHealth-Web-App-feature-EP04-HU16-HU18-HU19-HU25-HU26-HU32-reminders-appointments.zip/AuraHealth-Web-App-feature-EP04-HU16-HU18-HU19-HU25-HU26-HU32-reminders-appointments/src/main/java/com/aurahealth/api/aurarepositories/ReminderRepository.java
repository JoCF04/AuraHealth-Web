package com.aurahealth.api.aurarepositories;

import com.aurahealth.api.auraentities.Reminder;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Repository
public interface ReminderRepository extends JpaRepository<Reminder, Long> {

    // HU18 — Listar todos los recordatorios del usuario, ordenados por fecha
    List<Reminder> findByUserIdOrderByScheduledDateAsc(Long userId);

    // HU18 — Filtrar por tipo (medical | medicine | exam | vaccine)
    List<Reminder> findByUserIdAndReminderTypeIgnoreCaseOrderByScheduledDateAsc(
            Long userId, String reminderType);

    // HU18 — Recordatorios pendientes: no completados con fecha >= hoy
    List<Reminder> findByUserIdAndIsDoneFalseAndScheduledDateGreaterThanEqualOrderByScheduledDateAsc(
            Long userId, LocalDate today);

    // HU32 — Recordatorios vencidos: no completados con fecha < hoy
    List<Reminder> findByUserIdAndIsDoneFalseAndScheduledDateBeforeOrderByScheduledDateDesc(
            Long userId, LocalDate today);

    // Validación de pertenencia: el recordatorio debe ser del usuario indicado
    Optional<Reminder> findByIdAndUserId(Long id, Long userId);

    // Conteo para el badge de "tienes X recordatorios pendientes hoy"
    @Query("SELECT COUNT(r) FROM Reminder r " +
           "WHERE r.user.id = :userId " +
           "AND r.isDone = false " +
           "AND r.scheduledDate = :today")
    Long countPendientesHoy(@Param("userId") Long userId,
                            @Param("today") LocalDate today);
}
