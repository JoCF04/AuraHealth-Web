package com.aurahealth.api.auracontrollers;

import com.aurahealth.api.auradtos.*;
import com.aurahealth.api.auraservices.ReminderService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1")
@Tag(
    name        = "Reminders & Appointments",
    description = "EP04 — Gestión de recordatorios de salud y citas médicas"
)
public class ReminderController {

    private final ReminderService reminderService;

    public ReminderController(ReminderService reminderService) {
        this.reminderService = reminderService;
    }

    // ════════════════════════════════════════════════════════════════════════
    //  RECORDATORIOS — HU16, HU18, HU19, HU32
    // ════════════════════════════════════════════════════════════════════════

    @Operation(
        summary     = "HU16 — Crear un recordatorio de salud",
        description = "Crea un nuevo recordatorio para el usuario. "
                    + "Tipos válidos: medical, medicine, exam, vaccine.")
    @ApiResponses({
        @ApiResponse(responseCode = "201", description = "Recordatorio creado exitosamente"),
        @ApiResponse(responseCode = "400", description = "Datos inválidos o tipo de recordatorio incorrecto"),
        @ApiResponse(responseCode = "404", description = "Usuario no encontrado")
    })
    @PostMapping("/users/{userId}/reminders")
    public ResponseEntity<ReminderResponseDTO> crearRecordatorio(
            @Parameter(description = "ID del usuario", example = "1", required = true)
            @PathVariable Long userId,
            @Valid @RequestBody ReminderRequestDTO requestDTO) {
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(reminderService.crearRecordatorio(userId, requestDTO));
    }

    // ----------------------------------------------------------------

    @Operation(
        summary     = "HU18 — Listar recordatorios del usuario",
        description = "Devuelve todos los recordatorios del usuario ordenados por fecha. "
                    + "Usa el parámetro opcional 'type' para filtrar: medical | medicine | exam | vaccine.")
    @ApiResponses({
        @ApiResponse(responseCode = "200", description = "Lista de recordatorios obtenida"),
        @ApiResponse(responseCode = "404", description = "Usuario no encontrado")
    })
    @GetMapping("/users/{userId}/reminders")
    public ResponseEntity<List<ReminderResponseDTO>> listarRecordatorios(
            @Parameter(description = "ID del usuario", example = "1", required = true)
            @PathVariable Long userId,
            @Parameter(description = "Filtro por tipo: medical | medicine | exam | vaccine")
            @RequestParam(required = false) String type) {
        return ResponseEntity.ok(reminderService.listarRecordatorios(userId, type));
    }

    // ----------------------------------------------------------------

    @Operation(
        summary     = "HU18 — Obtener detalle de un recordatorio",
        description = "Retorna el detalle completo de un recordatorio. "
                    + "Valida que el recordatorio pertenezca al usuario indicado.")
    @ApiResponses({
        @ApiResponse(responseCode = "200", description = "Recordatorio encontrado"),
        @ApiResponse(responseCode = "404", description = "Recordatorio o usuario no encontrado")
    })
    @GetMapping("/users/{userId}/reminders/{id}")
    public ResponseEntity<ReminderResponseDTO> obtenerRecordatorio(
            @Parameter(description = "ID del usuario",       example = "1", required = true)
            @PathVariable Long userId,
            @Parameter(description = "ID del recordatorio",  example = "5", required = true)
            @PathVariable Long id) {
        return ResponseEntity.ok(reminderService.obtenerRecordatorioPorId(userId, id));
    }

    // ----------------------------------------------------------------

    @Operation(
        summary     = "HU16 — Actualizar un recordatorio existente",
        description = "Actualiza todos los campos de un recordatorio (PUT completo). "
                    + "No modifica el estado isDone; usa el endpoint /complete para eso.")
    @ApiResponses({
        @ApiResponse(responseCode = "200", description = "Recordatorio actualizado"),
        @ApiResponse(responseCode = "400", description = "Datos inválidos"),
        @ApiResponse(responseCode = "404", description = "Recordatorio o usuario no encontrado")
    })
    @PutMapping("/users/{userId}/reminders/{id}")
    public ResponseEntity<ReminderResponseDTO> actualizarRecordatorio(
            @Parameter(description = "ID del usuario",      example = "1", required = true)
            @PathVariable Long userId,
            @Parameter(description = "ID del recordatorio", example = "5", required = true)
            @PathVariable Long id,
            @Valid @RequestBody ReminderRequestDTO requestDTO) {
        return ResponseEntity.ok(reminderService.actualizarRecordatorio(userId, id, requestDTO));
    }

    // ----------------------------------------------------------------

    @Operation(
        summary     = "HU19 — Marcar recordatorio como completado",
        description = "Acción del checkbox en la tarjeta del recordatorio. "
                    + "Cambia isDone a true. Devuelve 409 si ya estaba completado.")
    @ApiResponses({
        @ApiResponse(responseCode = "200", description = "Recordatorio marcado como completado"),
        @ApiResponse(responseCode = "404", description = "Recordatorio o usuario no encontrado"),
        @ApiResponse(responseCode = "409", description = "El recordatorio ya estaba completado")
    })
    @PatchMapping("/users/{userId}/reminders/{id}/complete")
    public ResponseEntity<ReminderResponseDTO> marcarComoCompletado(
            @Parameter(description = "ID del usuario",      example = "1", required = true)
            @PathVariable Long userId,
            @Parameter(description = "ID del recordatorio", example = "5", required = true)
            @PathVariable Long id) {
        return ResponseEntity.ok(reminderService.marcarComoCompletado(userId, id));
    }

    // ----------------------------------------------------------------

    @Operation(
        summary     = "Eliminar un recordatorio",
        description = "Elimina permanentemente un recordatorio del usuario.")
    @ApiResponses({
        @ApiResponse(responseCode = "204", description = "Recordatorio eliminado"),
        @ApiResponse(responseCode = "404", description = "Recordatorio o usuario no encontrado")
    })
    @DeleteMapping("/users/{userId}/reminders/{id}")
    public ResponseEntity<Void> eliminarRecordatorio(
            @Parameter(description = "ID del usuario",      example = "1", required = true)
            @PathVariable Long userId,
            @Parameter(description = "ID del recordatorio", example = "5", required = true)
            @PathVariable Long id) {
        reminderService.eliminarRecordatorio(userId, id);
        return ResponseEntity.noContent().build();
    }

    // ----------------------------------------------------------------

    @Operation(
        summary     = "HU18 — Listar recordatorios pendientes",
        description = "Devuelve recordatorios no completados con fecha mayor o igual a hoy, "
                    + "ordenados cronológicamente.")
    @ApiResponses({
        @ApiResponse(responseCode = "200", description = "Lista de pendientes obtenida"),
        @ApiResponse(responseCode = "404", description = "Usuario no encontrado")
    })
    @GetMapping("/users/{userId}/reminders/pending")
    public ResponseEntity<List<ReminderResponseDTO>> listarPendientes(
            @Parameter(description = "ID del usuario", example = "1", required = true)
            @PathVariable Long userId) {
        return ResponseEntity.ok(reminderService.listarPendientes(userId));
    }

    // ----------------------------------------------------------------

    @Operation(
        summary     = "HU32 — Listar recordatorios vencidos",
        description = "Devuelve recordatorios no completados cuya fecha ya pasó. "
                    + "El frontend los muestra con indicador visual de 'vencido'.")
    @ApiResponses({
        @ApiResponse(responseCode = "200", description = "Lista de vencidos obtenida"),
        @ApiResponse(responseCode = "404", description = "Usuario no encontrado")
    })
    @GetMapping("/users/{userId}/reminders/overdue")
    public ResponseEntity<List<ReminderResponseDTO>> listarVencidos(
            @Parameter(description = "ID del usuario", example = "1", required = true)
            @PathVariable Long userId) {
        return ResponseEntity.ok(reminderService.listarVencidos(userId));
    }

    // ════════════════════════════════════════════════════════════════════════
    //  CITAS MÉDICAS — HU25, HU26
    // ════════════════════════════════════════════════════════════════════════

    @Operation(
        summary     = "HU25 — Agendar una nueva cita médica",
        description = "Registra una cita con médico, especialidad, clínica, fecha y hora.")
    @ApiResponses({
        @ApiResponse(responseCode = "201", description = "Cita agendada exitosamente"),
        @ApiResponse(responseCode = "400", description = "Fecha inválida o campos obligatorios vacíos"),
        @ApiResponse(responseCode = "404", description = "Usuario no encontrado")
    })
    @PostMapping("/users/{userId}/appointments")
    public ResponseEntity<AppointmentResponseDTO> agendarCita(
            @Parameter(description = "ID del usuario", example = "1", required = true)
            @PathVariable Long userId,
            @Valid @RequestBody AppointmentRequestDTO requestDTO) {
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(reminderService.agendarCita(userId, requestDTO));
    }

    // ----------------------------------------------------------------

    @Operation(
        summary     = "HU26 — Listar todas las citas del usuario",
        description = "Devuelve el historial completo de citas ordenadas por fecha.")
    @ApiResponses({
        @ApiResponse(responseCode = "200", description = "Lista de citas obtenida"),
        @ApiResponse(responseCode = "404", description = "Usuario no encontrado")
    })
    @GetMapping("/users/{userId}/appointments")
    public ResponseEntity<List<AppointmentResponseDTO>> listarCitas(
            @Parameter(description = "ID del usuario", example = "1", required = true)
            @PathVariable Long userId) {
        return ResponseEntity.ok(reminderService.listarCitas(userId));
    }

    // ----------------------------------------------------------------

    @Operation(
        summary     = "HU26 — Obtener detalle de una cita",
        description = "Retorna el detalle completo de una cita. "
                    + "Valida que pertenezca al usuario indicado.")
    @ApiResponses({
        @ApiResponse(responseCode = "200", description = "Cita encontrada"),
        @ApiResponse(responseCode = "404", description = "Cita o usuario no encontrado")
    })
    @GetMapping("/users/{userId}/appointments/{id}")
    public ResponseEntity<AppointmentResponseDTO> obtenerCita(
            @Parameter(description = "ID del usuario", example = "1", required = true)
            @PathVariable Long userId,
            @Parameter(description = "ID de la cita",  example = "3", required = true)
            @PathVariable Long id) {
        return ResponseEntity.ok(reminderService.obtenerCitaPorId(userId, id));
    }

    // ----------------------------------------------------------------

    @Operation(
        summary     = "HU26 — Listar próximas citas",
        description = "Devuelve citas con fecha >= hoy para el widget del dashboard.")
    @ApiResponses({
        @ApiResponse(responseCode = "200", description = "Lista de próximas citas obtenida"),
        @ApiResponse(responseCode = "404", description = "Usuario no encontrado")
    })
    @GetMapping("/users/{userId}/appointments/upcoming")
    public ResponseEntity<List<AppointmentResponseDTO>> listarProximasCitas(
            @Parameter(description = "ID del usuario", example = "1", required = true)
            @PathVariable Long userId) {
        return ResponseEntity.ok(reminderService.listarProximasCitas(userId));
    }

    // ----------------------------------------------------------------

    @Operation(
        summary     = "HU25 — Actualizar una cita médica",
        description = "Modifica todos los campos de una cita agendada (PUT completo).")
    @ApiResponses({
        @ApiResponse(responseCode = "200", description = "Cita actualizada"),
        @ApiResponse(responseCode = "400", description = "Datos inválidos"),
        @ApiResponse(responseCode = "404", description = "Cita o usuario no encontrado")
    })
    @PutMapping("/users/{userId}/appointments/{id}")
    public ResponseEntity<AppointmentResponseDTO> actualizarCita(
            @Parameter(description = "ID del usuario", example = "1", required = true)
            @PathVariable Long userId,
            @Parameter(description = "ID de la cita",  example = "3", required = true)
            @PathVariable Long id,
            @Valid @RequestBody AppointmentRequestDTO requestDTO) {
        return ResponseEntity.ok(reminderService.actualizarCita(userId, id, requestDTO));
    }

    // ----------------------------------------------------------------

    @Operation(
        summary     = "HU25 — Cancelar una cita médica",
        description = "Elimina permanentemente una cita del sistema.")
    @ApiResponses({
        @ApiResponse(responseCode = "204", description = "Cita cancelada"),
        @ApiResponse(responseCode = "404", description = "Cita o usuario no encontrado")
    })
    @DeleteMapping("/users/{userId}/appointments/{id}")
    public ResponseEntity<Void> cancelarCita(
            @Parameter(description = "ID del usuario", example = "1", required = true)
            @PathVariable Long userId,
            @Parameter(description = "ID de la cita",  example = "3", required = true)
            @PathVariable Long id) {
        reminderService.cancelarCita(userId, id);
        return ResponseEntity.noContent().build();
    }
}
