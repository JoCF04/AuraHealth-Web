package com.aurahealth.api.aurarepositories;

import com.aurahealth.api.auraentities.Appointment;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Repository
public interface AppointmentRepository extends JpaRepository<Appointment, Long> {

    // HU26 — Listar todas las citas del usuario ordenadas por fecha
    List<Appointment> findByUserIdOrderByAppointmentDateAsc(Long userId);

    // HU26 — Próximas citas: fecha >= hoy, ordenadas cronológicamente
    List<Appointment> findByUserIdAndAppointmentDateGreaterThanEqualOrderByAppointmentDateAsc(
            Long userId, LocalDate today);

    // Validación de pertenencia: la cita debe ser del usuario indicado
    Optional<Appointment> findByIdAndUserId(Long id, Long userId);
}
