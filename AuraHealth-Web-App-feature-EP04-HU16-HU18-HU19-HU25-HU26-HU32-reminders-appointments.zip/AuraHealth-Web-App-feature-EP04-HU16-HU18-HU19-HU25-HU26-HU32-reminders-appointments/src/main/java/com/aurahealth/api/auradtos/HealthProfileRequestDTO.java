package com.aurahealth.api.auradtos;

import lombok.*;
import java.math.BigDecimal;

/**
 * DTO de entrada para HU12 / HU20 — Actualización del perfil de salud.
 * Todos los campos son opcionales: se actualiza solo lo que se envíe.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class HealthProfileRequestDTO {

    private String bloodType;
    private String bloodPressure;
    private BigDecimal glucoseLevel;
    private BigDecimal cholesterolLevel;
    private String allergies;
    private BigDecimal weightKg;
    private BigDecimal heightCm;
}
