package com.aurahealth.api.auraservices;

import com.aurahealth.api.auraentities.Appointment;
import com.aurahealth.api.auraentities.Reminder;
import com.aurahealth.api.auraentities.User;
import com.aurahealth.api.aurarepositories.AppointmentRepository;
import com.aurahealth.api.aurarepositories.ReminderRepository;
import com.aurahealth.api.aurarepositories.UserRepository;
import com.aurahealth.api.auradtos.*;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class ReminderService {

    private final ReminderRepository    reminderRepository;
    private final AppointmentRepository appointmentRepository;
    private final UserRepository        userRepository;

    public ReminderService(ReminderRepository reminderRepository,
                           AppointmentRepository appointmentRepository,
                           UserRepository userRepository) {
        this.reminderRepository    = reminderRepository;
        this.appointmentRepository = appointmentRepository;
        this.userRepository        = userRepository;
    }

    // ════════════════════════════════════════════════════════════════════════
    //  RECORDATORIOS — HU16, HU18, HU19, HU32
    // ════════════════════════════════════════════════════════════════════════

    /**
     * HU16 — Crear un nuevo recordatorio para el usuario.
     */
    @Transactional
    public ReminderResponseDTO crearRecordatorio(Long userId,
                                                  ReminderRequestDTO dto) {
        User user = obtenerUsuarioOLanzar404(userId);
        Reminder reminder = new Reminder();
        mapearRequestAReminder(dto, reminder, user);
        return mapearAReminderResponseDTO(reminderRepository.save(reminder));
    }

    /**
     * HU18 — Listar todos los recordatorios del usuario, ordenados por fecha.
     * Si se pasa 'type', filtra por ese tipo específico.
     */
    @Transactional(readOnly = true)
    public List<ReminderResponseDTO> listarRecordatorios(Long userId, String type) {
        validarUsuarioExiste(userId);
        List<Reminder> lista = (type != null && !type.isBlank())
                ? reminderRepository.findByUserIdAndReminderTypeIgnoreCaseOrderByScheduledDateAsc(userId, type)
                : reminderRepository.findByUserIdOrderByScheduledDateAsc(userId);
        return lista.stream()
                .map(this::mapearAReminderResponseDTO)
                .collect(Collectors.toList());
    }

    /**
     * HU18 — Obtener el detalle de un recordatorio por ID.
     * Valida que el recordatorio pertenezca al usuario indicado.
     */
    @Transactional(readOnly = true)
    public ReminderResponseDTO obtenerRecordatorioPorId(Long userId, Long id) {
        return mapearAReminderResponseDTO(obtenerReminderOLanzar404(userId, id));
    }

    /**
     * HU16 — Actualizar un recordatorio existente (PUT completo).
     */
    @Transactional
    public ReminderResponseDTO actualizarRecordatorio(Long userId, Long id,
                                                       ReminderRequestDTO dto) {
        User user = obtenerUsuarioOLanzar404(userId);
        Reminder reminder = obtenerReminderOLanzar404(userId, id);
        mapearRequestAReminder(dto, reminder, user);
        return mapearAReminderResponseDTO(reminderRepository.save(reminder));
    }

    /**
     * HU19 — Marcar un recordatorio como completado (PATCH).
     * Acción del checkbox en la tarjeta del recordatorio.
     */
    @Transactional
    public ReminderResponseDTO marcarComoCompletado(Long userId, Long id) {
        Reminder reminder = obtenerReminderOLanzar404(userId, id);
        if (Boolean.TRUE.equals(reminder.getIsDone())) {
            throw new ResponseStatusException(HttpStatus.CONFLICT,
                    "El recordatorio con id " + id + " ya estaba marcado como completado");
        }
        reminder.setIsDone(Boolean.TRUE);
        return mapearAReminderResponseDTO(reminderRepository.save(reminder));
    }

    /**
     * Eliminar un recordatorio por ID (DELETE).
     */
    @Transactional
    public void eliminarRecordatorio(Long userId, Long id) {
        Reminder reminder = obtenerReminderOLanzar404(userId, id);
        reminderRepository.delete(reminder);
    }

    /**
     * HU18 — Listar recordatorios pendientes (no completados, fecha >= hoy).
     */
    @Transactional(readOnly = true)
    public List<ReminderResponseDTO> listarPendientes(Long userId) {
        validarUsuarioExiste(userId);
        return reminderRepository
                .findByUserIdAndIsDoneFalseAndScheduledDateGreaterThanEqualOrderByScheduledDateAsc(
                        userId, LocalDate.now())
                .stream()
                .map(this::mapearAReminderResponseDTO)
                .collect(Collectors.toList());
    }

    /**
     * HU32 — Listar recordatorios vencidos (no completados, fecha < hoy).
     */
    @Transactional(readOnly = true)
    public List<ReminderResponseDTO> listarVencidos(Long userId) {
        validarUsuarioExiste(userId);
        return reminderRepository
                .findByUserIdAndIsDoneFalseAndScheduledDateBeforeOrderByScheduledDateDesc(
                        userId, LocalDate.now())
                .stream()
                .map(this::mapearAReminderResponseDTO)
                .collect(Collectors.toList());
    }

    // ════════════════════════════════════════════════════════════════════════
    //  CITAS MÉDICAS — HU25, HU26
    // ════════════════════════════════════════════════════════════════════════

    /**
     * HU25 — Agendar una nueva cita médica.
     */
    @Transactional
    public AppointmentResponseDTO agendarCita(Long userId,
                                               AppointmentRequestDTO dto) {
        User user = obtenerUsuarioOLanzar404(userId);
        Appointment cita = new Appointment();
        mapearRequestAAppointment(dto, cita, user);
        return mapearAAppointmentResponseDTO(appointmentRepository.save(cita));
    }

    /**
     * HU26 — Listar todas las citas del usuario ordenadas por fecha.
     */
    @Transactional(readOnly = true)
    public List<AppointmentResponseDTO> listarCitas(Long userId) {
        validarUsuarioExiste(userId);
        return appointmentRepository.findByUserIdOrderByAppointmentDateAsc(userId)
                .stream()
                .map(this::mapearAAppointmentResponseDTO)
                .collect(Collectors.toList());
    }

    /**
     * HU26 — Obtener el detalle de una cita por ID.
     */
    @Transactional(readOnly = true)
    public AppointmentResponseDTO obtenerCitaPorId(Long userId, Long id) {
        return mapearAAppointmentResponseDTO(obtenerAppointmentOLanzar404(userId, id));
    }

    /**
     * HU26 — Listar próximas citas (fecha >= hoy), para el widget del dashboard.
     */
    @Transactional(readOnly = true)
    public List<AppointmentResponseDTO> listarProximasCitas(Long userId) {
        validarUsuarioExiste(userId);
        return appointmentRepository
                .findByUserIdAndAppointmentDateGreaterThanEqualOrderByAppointmentDateAsc(
                        userId, LocalDate.now())
                .stream()
                .map(this::mapearAAppointmentResponseDTO)
                .collect(Collectors.toList());
    }

    /**
     * HU25 — Actualizar una cita médica existente (PUT completo).
     */
    @Transactional
    public AppointmentResponseDTO actualizarCita(Long userId, Long id,
                                                  AppointmentRequestDTO dto) {
        User user = obtenerUsuarioOLanzar404(userId);
        Appointment cita = obtenerAppointmentOLanzar404(userId, id);
        mapearRequestAAppointment(dto, cita, user);
        return mapearAAppointmentResponseDTO(appointmentRepository.save(cita));
    }

    /**
     * Cancelar / eliminar una cita médica (DELETE).
     */
    @Transactional
    public void cancelarCita(Long userId, Long id) {
        Appointment cita = obtenerAppointmentOLanzar404(userId, id);
        appointmentRepository.delete(cita);
    }

    // ════════════════════════════════════════════════════════════════════════
    //  Helpers de validación
    // ════════════════════════════════════════════════════════════════════════

    private User obtenerUsuarioOLanzar404(Long userId) {
        return userRepository.findById(userId)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND,
                        "Usuario no encontrado con id: " + userId));
    }

    private void validarUsuarioExiste(Long userId) {
        if (!userRepository.existsById(userId)) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND,
                    "Usuario no encontrado con id: " + userId);
        }
    }

    private Reminder obtenerReminderOLanzar404(Long userId, Long id) {
        return reminderRepository.findByIdAndUserId(id, userId)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND,
                        "Recordatorio con id " + id + " no encontrado para el usuario " + userId));
    }

    private Appointment obtenerAppointmentOLanzar404(Long userId, Long id) {
        return appointmentRepository.findByIdAndUserId(id, userId)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND,
                        "Cita con id " + id + " no encontrada para el usuario " + userId));
    }

    // ════════════════════════════════════════════════════════════════════════
    //  Mapeos manuales (sin ModelMapper — patrón del proyecto)
    // ════════════════════════════════════════════════════════════════════════

    private void mapearRequestAReminder(ReminderRequestDTO dto,
                                        Reminder reminder,
                                        User user) {
        reminder.setUser(user);
        reminder.setTitle(dto.getTitle());
        reminder.setReminderType(dto.getReminderType().toLowerCase());
        reminder.setScheduledDate(LocalDate.parse(dto.getScheduledDate()));
        reminder.setScheduledTime(
                dto.getScheduledTime() != null && !dto.getScheduledTime().isBlank()
                        ? LocalTime.parse(dto.getScheduledTime())
                        : null);
        // Al crear, isDone empieza en false; al actualizar, se conserva el valor previo
        if (reminder.getIsDone() == null) reminder.setIsDone(Boolean.FALSE);
    }

    private ReminderResponseDTO mapearAReminderResponseDTO(Reminder r) {
        ReminderResponseDTO dto = new ReminderResponseDTO();
        dto.setId(r.getId());
        dto.setUserId(r.getUser().getId());
        dto.setTitle(r.getTitle());
        dto.setReminderType(r.getReminderType());
        dto.setScheduledDate(r.getScheduledDate());
        dto.setScheduledTime(r.getScheduledTime());
        dto.setIsDone(r.getIsDone());
        return dto;
    }

    private void mapearRequestAAppointment(AppointmentRequestDTO dto,
                                           Appointment cita,
                                           User user) {
        cita.setUser(user);
        cita.setDoctorName(dto.getDoctorName());
        cita.setSpecialty(dto.getSpecialty());
        cita.setClinicName(dto.getClinicName());
        cita.setAppointmentDate(LocalDate.parse(dto.getAppointmentDate()));
        cita.setAppointmentTime(
                dto.getAppointmentTime() != null && !dto.getAppointmentTime().isBlank()
                        ? LocalTime.parse(dto.getAppointmentTime())
                        : null);
        cita.setNotes(dto.getNotes());
        cita.setIsConfirmed(
                dto.getIsConfirmed() != null ? dto.getIsConfirmed() : Boolean.FALSE);
    }

    private AppointmentResponseDTO mapearAAppointmentResponseDTO(Appointment a) {
        AppointmentResponseDTO dto = new AppointmentResponseDTO();
        dto.setId(a.getId());
        dto.setUserId(a.getUser().getId());
        dto.setDoctorName(a.getDoctorName());
        dto.setSpecialty(a.getSpecialty());
        dto.setClinicName(a.getClinicName());
        dto.setAppointmentDate(a.getAppointmentDate());
        dto.setAppointmentTime(a.getAppointmentTime());
        dto.setNotes(a.getNotes());
        dto.setIsConfirmed(a.getIsConfirmed());
        dto.setCreatedAt(a.getCreatedAt());
        return dto;
    }
}
