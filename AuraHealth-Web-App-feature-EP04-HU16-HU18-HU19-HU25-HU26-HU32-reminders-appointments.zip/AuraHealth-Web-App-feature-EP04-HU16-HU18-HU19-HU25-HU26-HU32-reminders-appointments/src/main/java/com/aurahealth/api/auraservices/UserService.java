package com.aurahealth.api.auraservices;

import com.aurahealth.api.auradtos.*;
import com.aurahealth.api.auraentities.*;
import com.aurahealth.api.aurarepositories.*;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

import java.time.LocalDate;

@Service
public class UserService {

    private final UserRepository userRepository;
    private final HealthProfileRepository healthProfileRepository;

    public UserService(UserRepository userRepository,
                       HealthProfileRepository healthProfileRepository) {
        this.userRepository = userRepository;
        this.healthProfileRepository = healthProfileRepository;
    }

    // ----------------------------------------------------------------
    //  HU01 — Registro de usuario
    // ----------------------------------------------------------------

    @Transactional
    public UserResponseDTO registrarUsuario(UserRegistrationRequestDTO dto) {
        if (userRepository.existsByEmail(dto.getEmail())) {
            throw new ResponseStatusException(HttpStatus.CONFLICT,
                    "El correo electrónico ya está registrado: " + dto.getEmail());
        }
        User user = mapearRegistroAEntidad(dto);
        User guardado = userRepository.save(user);
        return mapearAUserResponseDTO(guardado);
    }

    // ----------------------------------------------------------------
    //  HU02 — Visualización de información personal y médica
    // ----------------------------------------------------------------

    public UserResponseDTO obtenerUsuarioPorId(Long id) {
        User user = userRepository.findByIdWithHealthProfile(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND,
                        "Usuario no encontrado con id: " + id));
        return mapearAUserResponseDTO(user);
    }

    // ----------------------------------------------------------------
    //  HU12 / HU20 — Actualización de perfil de salud
    //  Crea el perfil si no existe (upsert), lo actualiza si ya existe.
    // ----------------------------------------------------------------

    @Transactional
    public HealthProfileResponseDTO actualizarPerfilDeSalud(Long userId,
                                                             HealthProfileRequestDTO dto) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND,
                        "Usuario no encontrado con id: " + userId));

        HealthProfile perfil = healthProfileRepository.findById(userId)
                .orElseGet(() -> {
                    HealthProfile nuevo = new HealthProfile();
                    nuevo.setUser(user);
                    return nuevo;
                });

        perfil.setBloodType(dto.getBloodType());
        perfil.setBloodPressure(dto.getBloodPressure());
        perfil.setGlucoseLevel(dto.getGlucoseLevel());
        perfil.setCholesterolLevel(dto.getCholesterolLevel());
        perfil.setAllergies(dto.getAllergies());
        perfil.setWeightKg(dto.getWeightKg());
        perfil.setHeightCm(dto.getHeightCm());

        HealthProfile guardado = healthProfileRepository.save(perfil);
        return mapearAHealthProfileResponseDTO(guardado);
    }

    // ----------------------------------------------------------------
    //  Métodos de mapeo manual (sin ModelMapper)
    // ----------------------------------------------------------------

    private User mapearRegistroAEntidad(UserRegistrationRequestDTO dto) {
        User user = new User();
        user.setFirstName(dto.getFirstName());
        user.setLastName(dto.getLastName());
        user.setEmail(dto.getEmail());
        // TODO: reemplazar por BCryptPasswordEncoder cuando se integre Spring Security
        user.setPasswordHash(dto.getPassword());
        if (dto.getBirthDate() != null && !dto.getBirthDate().isBlank()) {
            user.setBirthDate(LocalDate.parse(dto.getBirthDate()));
        }
        user.setGender(dto.getGender());
        user.setPreferredLanguage(
                dto.getPreferredLanguage() != null ? dto.getPreferredLanguage() : "es");
        return user;
    }

    private UserResponseDTO mapearAUserResponseDTO(User user) {
        UserResponseDTO dto = new UserResponseDTO();
        dto.setId(user.getId());
        dto.setFirstName(user.getFirstName());
        dto.setLastName(user.getLastName());
        dto.setEmail(user.getEmail());
        dto.setBirthDate(user.getBirthDate());
        dto.setGender(user.getGender());
        dto.setIsEmailVerified(user.getIsEmailVerified());
        dto.setPreferredLanguage(user.getPreferredLanguage());
        dto.setCreatedAt(user.getCreatedAt());
        if (user.getHealthProfile() != null) {
            dto.setHealthProfile(mapearAHealthProfileResponseDTO(user.getHealthProfile()));
        }
        return dto;
    }

    private HealthProfileResponseDTO mapearAHealthProfileResponseDTO(HealthProfile hp) {
        HealthProfileResponseDTO dto = new HealthProfileResponseDTO();
        dto.setUserId(hp.getUserId());
        dto.setBloodType(hp.getBloodType());
        dto.setBloodPressure(hp.getBloodPressure());
        dto.setGlucoseLevel(hp.getGlucoseLevel());
        dto.setCholesterolLevel(hp.getCholesterolLevel());
        dto.setAllergies(hp.getAllergies());
        dto.setWeightKg(hp.getWeightKg());
        dto.setHeightCm(hp.getHeightCm());
        return dto;
    }
}
