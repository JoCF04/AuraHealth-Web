package com.aurahealth.api.auraentities;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.LocalDateTime;

/**
 * Entidad que representa una cita médica agendada por el usuario.
 * Mapea a la tabla 'appointments' (nueva, ver SQL adjunto).
 *
 * HUs cubiertas: HU25 (agendar cita), HU26 (listar y ver próximas citas)
 */
@Entity
@Table(name = "appointments")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Appointment {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ToString.Exclude
    @EqualsAndHashCode.Exclude
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id", nullable = false)
    private User user;

    // Nombre del médico tratante
    @Column(name = "doctor_name")
    private String doctorName;

    // Especialidad médica (ej: "Cardiología", "Medicina General")
    @Column(name = "specialty")
    private String specialty;

    // Nombre del establecimiento o clínica
    @Column(name = "clinic_name")
    private String clinicName;

    // Fecha de la cita — obligatoria
    @Column(name = "appointment_date", nullable = false)
    private LocalDate appointmentDate;

    // Hora de la cita (opcional)
    @Column(name = "appointment_time")
    private LocalTime appointmentTime;

    // Notas adicionales (ej: "Llevar resultados de laboratorio")
    @Column(columnDefinition = "TEXT")
    private String notes;

    // HU26 — estado de confirmación de la cita
    @Column(name = "is_confirmed", nullable = false)
    private Boolean isConfirmed = Boolean.FALSE;

    @Column(name = "created_at", updatable = false)
    private LocalDateTime createdAt;

    @PrePersist
    protected void onCreate() {
        this.createdAt = LocalDateTime.now();
        if (this.isConfirmed == null) this.isConfirmed = Boolean.FALSE;
    }
}
