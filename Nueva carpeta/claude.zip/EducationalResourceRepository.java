package com.aurahealth.api.aurarepositories;

import com.aurahealth.api.auraentities.EducationalResource;
import com.aurahealth.api.auraentities.ResourceFormat;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface EducationalResourceRepository extends JpaRepository<EducationalResource, Long> {

    // HU23, HU07 — Listar todos los recursos publicados para la biblioteca y artículos
    List<EducationalResource> findByIsPublishedTrue();

    // HU34 — Filtrar recomendaciones por categoría (ej: "nutrition", "exercise")
    List<EducationalResource> findByCategoryIgnoreCaseAndIsPublishedTrue(String category);

    // HU37 — Filtrar biblioteca por tipo de formato (ARTICLE, INFOGRAPHIC, VIDEO, GUIDE)
    List<EducationalResource> findByFormatTypeAndIsPublishedTrue(ResourceFormat formatType);

    // HU41, HU33 — Búsqueda por texto libre en título O descripción (ContainingIgnoreCase)
    // Se usa @Query JPQL para centralizar la lógica de búsqueda en ambos campos
    @Query("SELECT r FROM EducationalResource r " +
           "WHERE r.isPublished = true " +
           "AND (LOWER(r.title) LIKE LOWER(CONCAT('%', :keyword, '%')) " +
           "     OR LOWER(r.description) LIKE LOWER(CONCAT('%', :keyword, '%')))")
    List<EducationalResource> buscarPorKeyword(@Param("keyword") String keyword);

    // HU09 — Verificar si un recurso ya está en favoritos antes de agregarlo
    @Query("SELECT COUNT(r) > 0 FROM EducationalResource r WHERE r.id = :id AND r.isPublished = true")
    boolean existsByIdAndIsPublishedTrue(@Param("id") Long id);
}
