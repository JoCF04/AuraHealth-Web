package com.aurahealth.api.auraentities;

/**
 * Tipos de formato disponibles para los recursos educativos.
 * Mapea a la columna 'format_type' VARCHAR(50) en la tabla educational_resources.
 * Nota: En la BD use VARCHAR(50) en lugar del tipo ENUM de PostgreSQL
 * para compatibilidad directa con @Enumerated(EnumType.STRING) de JPA.
 */
public enum ResourceFormat {
    ARTICLE,
    INFOGRAPHIC,
    VIDEO,
    GUIDE
}
