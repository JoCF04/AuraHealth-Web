package com.aurahealth.api.aurarepositories;

import com.aurahealth.api.auraentities.UserFavoriteResource;
import com.aurahealth.api.auraentities.UserFavoriteResourceId;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface UserFavoriteResourceRepository
        extends JpaRepository<UserFavoriteResource, UserFavoriteResourceId> {

    // HU09 — Listar todos los favoritos de un usuario (con datos del recurso incluidos)
    @Query("SELECT ufr FROM UserFavoriteResource ufr " +
           "JOIN FETCH ufr.resource r " +
           "WHERE ufr.id.userId = :userId " +
           "AND r.isPublished = true " +
           "ORDER BY ufr.savedAt DESC")
    List<UserFavoriteResource> findByIdUserIdOrderBySavedAtDesc(@Param("userId") Long userId);

    // HU09 — Validar si el favorito ya existe antes de intentar crearlo (evita duplicados)
    boolean existsByIdUserIdAndIdResourceId(Long userId, Long resourceId);
}
