package com.aurahealth.api.auraservices;

import com.aurahealth.api.auraentities.*;
import com.aurahealth.api.aurarepositories.*;
import com.aurahealth.api.auradtos.*;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class EducationalResourceService {

    private final EducationalResourceRepository recursoRepositorio;
    private final UserFavoriteResourceRepository favoritoRepositorio;
    private final DailyTipRepository consejoRepositorio;
    private final com.aurahealth.api.aurarepositories.UserRepository usuarioRepositorio;

    // Constructor injection — patrón del profesor (sin @Autowired)
    public EducationalResourceService(
            EducationalResourceRepository recursoRepositorio,
            UserFavoriteResourceRepository favoritoRepositorio,
            DailyTipRepository consejoRepositorio,
            com.aurahealth.api.aurarepositories.UserRepository usuarioRepositorio) {
        this.recursoRepositorio = recursoRepositorio;
        this.favoritoRepositorio = favoritoRepositorio;
        this.consejoRepositorio = consejoRepositorio;
        this.usuarioRepositorio = usuarioRepositorio;
    }

    // ── CRUD de Recursos Educativos ──────────────────────────────────────────

    /**
     * HU07, HU15, HU23 — Crear un nuevo recurso educativo (POST).
     * Retorna el recurso completo con HTTP 201.
     */
    public EducationalResourceResponseDTO crearRecurso(EducationalResourceRequestDTO requestDTO) {
        EducationalResource recurso = new EducationalResource();
        mapearRequestAEntidad(requestDTO, recurso);
        return mapearAResponseDTO(recursoRepositorio.save(recurso));
    }

    /**
     * HU07, HU15, HU23 — Listar todos los recursos publicados.
     * Devuelve DTO resumido (tarjeta/card) para optimizar el payload.
     */
    public List<EducationalResourceSummaryDTO> listarTodos() {
        return recursoRepositorio.findByIsPublishedTrue()
                .stream()
                .map(this::mapearASummaryDTO)
                .collect(Collectors.toList());
    }

    /**
     * HU42 — Obtener el detalle completo de un recurso por ID.
     * Lanza 404 si no existe o no está publicado.
     */
    public EducationalResourceResponseDTO obtenerPorId(Long id) {
        EducationalResource recurso = recursoRepositorio.findById(id)
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.NOT_FOUND,
                        "Recurso educativo con id " + id + " no encontrado"));
        if (Boolean.FALSE.equals(recurso.getIsPublished())) {
            throw new ResponseStatusException(
                    HttpStatus.NOT_FOUND,
                    "Recurso educativo con id " + id + " no está publicado");
        }
        return mapearAResponseDTO(recurso);
    }

    /**
     * Actualizar un recurso educativo por ID (PUT).
     * Lanza 404 si no existe.
     */
    public EducationalResourceResponseDTO actualizarRecurso(Long id,
            EducationalResourceRequestDTO requestDTO) {
        EducationalResource recurso = recursoRepositorio.findById(id)
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.NOT_FOUND,
                        "Recurso educativo con id " + id + " no encontrado"));
        mapearRequestAEntidad(requestDTO, recurso);
        return mapearAResponseDTO(recursoRepositorio.save(recurso));
    }

    /**
     * Eliminar un recurso educativo por ID (DELETE).
     * Lanza 404 si no existe.
     */
    public void eliminarRecurso(Long id) {
        if (!recursoRepositorio.existsById(id)) {
            throw new ResponseStatusException(
                    HttpStatus.NOT_FOUND,
                    "Recurso educativo con id " + id + " no encontrado");
        }
        recursoRepositorio.deleteById(id);
    }

    // ── Filtros y Búsqueda ───────────────────────────────────────────────────

    /**
     * HU34 — Filtrar recomendaciones por categoría (nutrition, prevention, exercise, etc.).
     * Los botones de filtro rápido del frontend invocan este endpoint.
     */
    public List<EducationalResourceSummaryDTO> listarPorCategoria(String categoria) {
        return recursoRepositorio.findByCategoryIgnoreCaseAndIsPublishedTrue(categoria)
                .stream()
                .map(this::mapearASummaryDTO)
                .collect(Collectors.toList());
    }

    /**
     * HU41, HU33 — Búsqueda por texto libre en título y descripción.
     * La barra de búsqueda del frontend invoca este endpoint en tiempo real.
     */
    public List<EducationalResourceSummaryDTO> buscarPorTexto(String keyword) {
        if (keyword == null || keyword.isBlank()) {
            return listarTodos();
        }
        return recursoRepositorio.buscarPorKeyword(keyword.trim())
                .stream()
                .map(this::mapearASummaryDTO)
                .collect(Collectors.toList());
    }

    /**
     * HU37 — Filtrar la biblioteca por tipo de formato (ARTICLE, INFOGRAPHIC, VIDEO, GUIDE).
     * Lanza 400 si el formato enviado no es válido.
     */
    public List<EducationalResourceSummaryDTO> listarPorFormato(String formatoStr) {
        ResourceFormat formato;
        try {
            formato = ResourceFormat.valueOf(formatoStr.toUpperCase());
        } catch (IllegalArgumentException e) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "Formato inválido: '" + formatoStr + "'. Valores aceptados: ARTICLE, INFOGRAPHIC, VIDEO, GUIDE");
        }
        return recursoRepositorio.findByFormatTypeAndIsPublishedTrue(formato)
                .stream()
                .map(this::mapearASummaryDTO)
                .collect(Collectors.toList());
    }

    // ── Daily Tips ───────────────────────────────────────────────────────────

    /**
     * HU04 — Obtener 3 consejos de bienestar aleatorios para el banner "Consejos para hoy".
     * Si hay menos de 3 consejos activos, devuelve todos los disponibles.
     */
    public List<DailyTipResponseDTO> obtenerConsejosDiarios() {
        List<DailyTip> consejos = consejoRepositorio.findByIsActiveTrue();
        Collections.shuffle(consejos); // Orden aleatorio para que el banner se sienta "fresco"
        return consejos.stream()
                .limit(3)
                .map(this::mapearADailyTipDTO)
                .collect(Collectors.toList());
    }

    // ── Favoritos ────────────────────────────────────────────────────────────

    /**
     * HU09 — Agregar un recurso a los favoritos del usuario.
     * Lanza 404 si el usuario o recurso no existen.
     * Lanza 409 si ya estaba en favoritos.
     */
    public FavoriteResourceResponseDTO guardarFavorito(Long userId, Long resourceId) {
        // Verificar existencia del usuario
        User usuario = usuarioRepositorio.findById(userId)
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.NOT_FOUND,
                        "Usuario con id " + userId + " no encontrado"));

        // Verificar existencia del recurso (y que esté publicado)
        EducationalResource recurso = recursoRepositorio.findById(resourceId)
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.NOT_FOUND,
                        "Recurso educativo con id " + resourceId + " no encontrado"));

        // Evitar duplicados
        if (favoritoRepositorio.existsByIdUserIdAndIdResourceId(userId, resourceId)) {
            throw new ResponseStatusException(
                    HttpStatus.CONFLICT,
                    "El recurso con id " + resourceId + " ya está en favoritos del usuario " + userId);
        }

        UserFavoriteResourceId pk = new UserFavoriteResourceId(userId, resourceId);
        UserFavoriteResource favorito = new UserFavoriteResource();
        favorito.setId(pk);
        favorito.setUser(usuario);
        favorito.setResource(recurso);

        UserFavoriteResource guardado = favoritoRepositorio.save(favorito);
        return mapearAFavoriteDTO(guardado);
    }

    /**
     * HU09 — Eliminar un recurso de los favoritos del usuario.
     * Lanza 404 si la relación no existe.
     */
    public void eliminarFavorito(Long userId, Long resourceId) {
        UserFavoriteResourceId pk = new UserFavoriteResourceId(userId, resourceId);
        if (!favoritoRepositorio.existsById(pk)) {
            throw new ResponseStatusException(
                    HttpStatus.NOT_FOUND,
                    "El recurso con id " + resourceId + " no está en favoritos del usuario " + userId);
        }
        favoritoRepositorio.deleteById(pk);
    }

    /**
     * HU09 — Listar todos los artículos favoritos de un usuario.
     * Lanza 404 si el usuario no existe.
     */
    public List<FavoriteResourceResponseDTO> listarFavoritos(Long userId) {
        if (!usuarioRepositorio.existsById(userId)) {
            throw new ResponseStatusException(
                    HttpStatus.NOT_FOUND,
                    "Usuario con id " + userId + " no encontrado");
        }
        return favoritoRepositorio.findByIdUserIdOrderBySavedAtDesc(userId)
                .stream()
                .map(this::mapearAFavoriteDTO)
                .collect(Collectors.toList());
    }

    // ── Mapeos manuales (patrón del profesor — sin ModelMapper) ──────────────

    private void mapearRequestAEntidad(EducationalResourceRequestDTO dto,
                                       EducationalResource recurso) {
        recurso.setTitle(dto.getTitle());
        recurso.setCategory(dto.getCategory());
        recurso.setDescription(dto.getDescription());
        recurso.setContent(dto.getContent());
        recurso.setImageUrl(dto.getImageUrl());
        recurso.setAuthor(dto.getAuthor());
        recurso.setDownloadUrl(dto.getDownloadUrl());
        recurso.setIsPublished(dto.getIsPublished() != null ? dto.getIsPublished() : Boolean.TRUE);

        // Parsear String → enum con validación
        if (dto.getFormatType() != null) {
            try {
                recurso.setFormatType(ResourceFormat.valueOf(dto.getFormatType().toUpperCase()));
            } catch (IllegalArgumentException e) {
                throw new ResponseStatusException(
                        HttpStatus.BAD_REQUEST,
                        "Formato inválido: '" + dto.getFormatType() + "'. Valores: ARTICLE, INFOGRAPHIC, VIDEO, GUIDE");
            }
        }
    }

    private EducationalResourceResponseDTO mapearAResponseDTO(EducationalResource recurso) {
        return new EducationalResourceResponseDTO(
                recurso.getId(),
                recurso.getTitle(),
                recurso.getCategory(),
                recurso.getDescription(),
                recurso.getContent(),
                recurso.getImageUrl(),
                recurso.getAuthor(),
                recurso.getFormatType() != null ? recurso.getFormatType().name() : null,
                recurso.getDownloadUrl(),
                recurso.getIsPublished(),
                recurso.getPublishedAt(),
                recurso.getCreatedAt()
        );
    }

    private EducationalResourceSummaryDTO mapearASummaryDTO(EducationalResource recurso) {
        return new EducationalResourceSummaryDTO(
                recurso.getId(),
                recurso.getTitle(),
                recurso.getCategory(),
                recurso.getDescription(),
                recurso.getImageUrl(),
                recurso.getAuthor(),
                recurso.getFormatType() != null ? recurso.getFormatType().name() : null
        );
    }

    private DailyTipResponseDTO mapearADailyTipDTO(DailyTip consejo) {
        return new DailyTipResponseDTO(
                consejo.getId(),
                consejo.getContent(),
                consejo.getCategory()
        );
    }

    private FavoriteResourceResponseDTO mapearAFavoriteDTO(UserFavoriteResource favorito) {
        EducationalResource recurso = favorito.getResource();
        return new FavoriteResourceResponseDTO(
                recurso.getId(),
                recurso.getTitle(),
                recurso.getCategory(),
                recurso.getImageUrl(),
                recurso.getFormatType() != null ? recurso.getFormatType().name() : null,
                favorito.getSavedAt()
        );
    }
}
