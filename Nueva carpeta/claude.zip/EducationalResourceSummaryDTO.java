package com.aurahealth.api.auradtos;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * DTO de salida reducido para la vista de tarjetas/cards en la cuadrícula de recomendaciones.
 * Omite el contenido completo para optimizar el payload en listados.
 *
 * Usado en:
 *   GET /api/v1/resources                    → HU07, HU15, HU23
 *   GET /api/v1/resources/category/{category} → HU34
 *   GET /api/v1/resources/search?keyword=     → HU41
 *   GET /api/v1/resources/format/{format}     → HU37
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class EducationalResourceSummaryDTO {

    private Long id;
    private String title;
    private String category;    // Tag de categoría visible en cada tarjeta (HU15)
    private String description; // Descripción corta; el frontend la trunca visualmente
    private String imageUrl;    // El frontend usa un fallback si es null (HU15)
    private String author;
    private String formatType;
}
