package com.aurahealth.api.aurarepositories;

import com.aurahealth.api.auraentities.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

/**
 * Repositorio del módulo de Usuarios.
 * Definido aquí como stub para que el módulo de Educational Resources compile.
 * El módulo de Autenticación/Perfil lo completará con métodos adicionales.
 */
@Repository
public interface UserRepository extends JpaRepository<User, Long> {
}
