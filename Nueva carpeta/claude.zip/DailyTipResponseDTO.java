// ─────────────────────────────────────────────────────────────────────────────
// ARCHIVO 1 de 2: DailyTipResponseDTO.java
// Ruta: src/main/java/com/aurahealth/api/auradtos/DailyTipResponseDTO.java
// ─────────────────────────────────────────────────────────────────────────────
package com.aurahealth.api.auradtos;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * DTO de salida para los consejos del banner "Consejos para hoy".
 * El endpoint GET /api/v1/daily-tips devuelve una lista de máximo 3 de estos.
 *
 * HU04 (EP05) — Visualizar banner de consejos rápidos.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class DailyTipResponseDTO {

    private Long id;
    private String content;
    private String category; // Para que el frontend asigne color según categoría
}
