package com.aurahealth.api.auraentities;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.time.LocalDateTime;

/**
 * Entidad que representa el vínculo entre un usuario y un recurso guardado en favoritos.
 * Corresponde a la tabla user_favorite_resources (relación muchos-a-muchos con datos extra).
 *
 * HUs cubiertas: HU09 (Guardar/eliminar/listar artículos favoritos)
 */
@Entity
@Table(name = "user_favorite_resources")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class UserFavoriteResource {

    @EmbeddedId
    private UserFavoriteResourceId id;

    // @MapsId delega el manejo de la columna FK al campo del @EmbeddedId
    @ManyToOne(fetch = FetchType.LAZY)
    @MapsId("userId")
    @JoinColumn(name = "user_id")
    private User user;

    @ManyToOne(fetch = FetchType.LAZY)
    @MapsId("resourceId")
    @JoinColumn(name = "resource_id")
    private EducationalResource resource;

    @Column(name = "saved_at", updatable = false)
    private LocalDateTime savedAt;

    @PrePersist
    protected void onPersist() {
        this.savedAt = LocalDateTime.now();
    }
}
