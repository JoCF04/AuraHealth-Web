package com.aurahealth.api.auracontrollers;

import com.aurahealth.api.auradtos.*;
import com.aurahealth.api.auraservices.EducationalResourceService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1")
@Tag(
    name = "Educational Resources",
    description = "EP05 Recomendaciones · EP08 Biblioteca · EP09 Artículos Educativos"
)
public class EducationalResourceController {

    private final EducationalResourceService recursoServicio;

    public EducationalResourceController(EducationalResourceService recursoServicio) {
        this.recursoServicio = recursoServicio;
    }

    // ════════════════════════════════════════════════════════════════════════
    //  CRUD — Gestión de Recursos Educativos
    // ════════════════════════════════════════════════════════════════════════

    /**
     * HU07, HU15, HU23 — Crear un nuevo recurso educativo.
     * Usado por administradores para poblar la biblioteca y la sección de artículos.
     */
    @Operation(summary = "HU07/HU15/HU23 - Crear un nuevo recurso educativo")
    @ApiResponses({
        @ApiResponse(responseCode = "201", description = "Recurso creado exitosamente"),
        @ApiResponse(responseCode = "400", description = "Datos de entrada inválidos")
    })
    @PostMapping("/resources")
    public ResponseEntity<EducationalResourceResponseDTO> crearRecurso(
            @Valid @RequestBody EducationalResourceRequestDTO requestDTO) {
        return ResponseEntity
                .status(HttpStatus.CREATED)
                .body(recursoServicio.crearRecurso(requestDTO));
    }

    /**
     * HU07, HU15, HU23 — Listar todos los recursos publicados en formato de tarjeta.
     * Respuesta reducida (SummaryDTO) para optimizar el payload en vistas de lista/grid.
     */
    @Operation(summary = "HU07/HU15/HU23 - Listar todos los recursos educativos publicados")
    @ApiResponses({
        @ApiResponse(responseCode = "200", description = "Lista de recursos obtenida exitosamente")
    })
    @GetMapping("/resources")
    public ResponseEntity<List<EducationalResourceSummaryDTO>> listarTodos() {
        return ResponseEntity.ok(recursoServicio.listarTodos());
    }

    /**
     * HU42 — Obtener el detalle completo de un recurso para la vista de lectura.
     * Incluye el campo `content` con el cuerpo completo del artículo.
     */
    @Operation(summary = "HU42 - Obtener detalle completo de un recurso educativo por ID")
    @ApiResponses({
        @ApiResponse(responseCode = "200", description = "Recurso encontrado"),
        @ApiResponse(responseCode = "404", description = "Recurso no encontrado o no publicado")
    })
    @GetMapping("/resources/{id}")
    public ResponseEntity<EducationalResourceResponseDTO> obtenerPorId(
            @Parameter(description = "ID del recurso educativo") @PathVariable Long id) {
        return ResponseEntity.ok(recursoServicio.obtenerPorId(id));
    }

    /**
     * Actualizar un recurso educativo existente (PUT).
     */
    @Operation(summary = "Actualizar un recurso educativo existente")
    @ApiResponses({
        @ApiResponse(responseCode = "200", description = "Recurso actualizado exitosamente"),
        @ApiResponse(responseCode = "400", description = "Datos de entrada inválidos"),
        @ApiResponse(responseCode = "404", description = "Recurso no encontrado")
    })
    @PutMapping("/resources/{id}")
    public ResponseEntity<EducationalResourceResponseDTO> actualizarRecurso(
            @Parameter(description = "ID del recurso a actualizar") @PathVariable Long id,
            @Valid @RequestBody EducationalResourceRequestDTO requestDTO) {
        return ResponseEntity.ok(recursoServicio.actualizarRecurso(id, requestDTO));
    }

    /**
     * Eliminar un recurso educativo por ID (DELETE).
     */
    @Operation(summary = "Eliminar un recurso educativo por ID")
    @ApiResponses({
        @ApiResponse(responseCode = "204", description = "Recurso eliminado exitosamente"),
        @ApiResponse(responseCode = "404", description = "Recurso no encontrado")
    })
    @DeleteMapping("/resources/{id}")
    public ResponseEntity<Void> eliminarRecurso(
            @Parameter(description = "ID del recurso a eliminar") @PathVariable Long id) {
        recursoServicio.eliminarRecurso(id);
        return ResponseEntity.noContent().build();
    }

    // ════════════════════════════════════════════════════════════════════════
    //  Filtros y Búsqueda
    // ════════════════════════════════════════════════════════════════════════

    /**
     * HU34 — Filtrar la cuadrícula de recomendaciones por categoría.
     * Los botones de filtro del frontend (Nutrición, Prevención, Ejercicio, Salud Mental)
     * invocan este endpoint pasando el valor en minúsculas (ej: "nutrition").
     */
    @Operation(
        summary = "HU34 - Filtrar recursos por categoría",
        description = "Valores válidos: nutrition, prevention, exercise, mental_health"
    )
    @ApiResponses({
        @ApiResponse(responseCode = "200", description = "Recursos filtrados exitosamente")
    })
    @GetMapping("/resources/category/{category}")
    public ResponseEntity<List<EducationalResourceSummaryDTO>> listarPorCategoria(
            @Parameter(description = "Categoría: nutrition | prevention | exercise | mental_health")
            @PathVariable String category) {
        return ResponseEntity.ok(recursoServicio.listarPorCategoria(category));
    }

    /**
     * HU41, HU33 — Búsqueda por texto libre.
     * Filtra por coincidencia en título O descripción (ContainingIgnoreCase).
     * La barra de búsqueda del frontend envía el parámetro 'keyword' en tiempo real.
     */
    @Operation(
        summary = "HU41/HU33 - Buscar recursos por palabra clave",
        description = "Busca coincidencias en título y descripción. Si keyword está vacío, devuelve todos."
    )
    @ApiResponses({
        @ApiResponse(responseCode = "200", description = "Resultados de búsqueda obtenidos")
    })
    @GetMapping("/resources/search")
    public ResponseEntity<List<EducationalResourceSummaryDTO>> buscarPorTexto(
            @Parameter(description = "Palabra clave a buscar en título y descripción")
            @RequestParam String keyword) {
        return ResponseEntity.ok(recursoServicio.buscarPorTexto(keyword));
    }

    /**
     * HU37 — Filtrar la biblioteca por tipo de formato.
     * Permite mostrar solo infografías, videos, guías o artículos.
     * Valores aceptados: ARTICLE, INFOGRAPHIC, VIDEO, GUIDE
     */
    @Operation(
        summary = "HU37 - Filtrar recursos por tipo de formato",
        description = "Valores válidos: ARTICLE, INFOGRAPHIC, VIDEO, GUIDE"
    )
    @ApiResponses({
        @ApiResponse(responseCode = "200", description = "Recursos filtrados por formato"),
        @ApiResponse(responseCode = "400", description = "Tipo de formato inválido")
    })
    @GetMapping("/resources/format/{format}")
    public ResponseEntity<List<EducationalResourceSummaryDTO>> listarPorFormato(
            @Parameter(description = "Formato: ARTICLE | INFOGRAPHIC | VIDEO | GUIDE")
            @PathVariable String format) {
        return ResponseEntity.ok(recursoServicio.listarPorFormato(format));
    }

    // ════════════════════════════════════════════════════════════════════════
    //  Daily Tips
    // ════════════════════════════════════════════════════════════════════════

    /**
     * HU04 — Obtener 3 consejos de bienestar aleatorios para el banner del día.
     * El orden es aleatorio para que el contenido se sienta "fresco" en cada carga.
     */
    @Operation(
        summary = "HU04 - Obtener consejos diarios de bienestar",
        description = "Devuelve hasta 3 tips aleatorios de los consejos activos en BD."
    )
    @ApiResponses({
        @ApiResponse(responseCode = "200", description = "Consejos del día obtenidos exitosamente")
    })
    @GetMapping("/daily-tips")
    public ResponseEntity<List<DailyTipResponseDTO>> obtenerConsejosDiarios() {
        return ResponseEntity.ok(recursoServicio.obtenerConsejosDiarios());
    }

    // ════════════════════════════════════════════════════════════════════════
    //  Favoritos
    // ════════════════════════════════════════════════════════════════════════

    /**
     * HU09 — Listar todos los artículos favoritos de un usuario.
     * Ordenados por fecha de guardado más reciente primero.
     */
    @Operation(summary = "HU09 - Listar artículos favoritos de un usuario")
    @ApiResponses({
        @ApiResponse(responseCode = "200", description = "Lista de favoritos obtenida"),
        @ApiResponse(responseCode = "404", description = "Usuario no encontrado")
    })
    @GetMapping("/users/{userId}/favorites")
    public ResponseEntity<List<FavoriteResourceResponseDTO>> listarFavoritos(
            @Parameter(description = "ID del usuario") @PathVariable Long userId) {
        return ResponseEntity.ok(recursoServicio.listarFavoritos(userId));
    }

    /**
     * HU09 — Agregar un recurso a los favoritos del usuario (botón "Agregar a Favoritos").
     * Lanza 409 Conflict si el recurso ya estaba en favoritos.
     */
    @Operation(summary = "HU09 - Agregar un recurso a los favoritos del usuario")
    @ApiResponses({
        @ApiResponse(responseCode = "201", description = "Recurso añadido a favoritos"),
        @ApiResponse(responseCode = "404", description = "Usuario o recurso no encontrado"),
        @ApiResponse(responseCode = "409", description = "El recurso ya está en favoritos")
    })
    @PostMapping("/resources/{resourceId}/favorites/{userId}")
    public ResponseEntity<FavoriteResourceResponseDTO> guardarFavorito(
            @Parameter(description = "ID del recurso educativo") @PathVariable Long resourceId,
            @Parameter(description = "ID del usuario")           @PathVariable Long userId) {
        return ResponseEntity
                .status(HttpStatus.CREATED)
                .body(recursoServicio.guardarFavorito(userId, resourceId));
    }

    /**
     * HU09 — Eliminar un recurso de los favoritos (desmarcar icono de favorito).
     */
    @Operation(summary = "HU09 - Eliminar un recurso de los favoritos del usuario")
    @ApiResponses({
        @ApiResponse(responseCode = "204", description = "Recurso eliminado de favoritos"),
        @ApiResponse(responseCode = "404", description = "El recurso no estaba en favoritos")
    })
    @DeleteMapping("/resources/{resourceId}/favorites/{userId}")
    public ResponseEntity<Void> eliminarFavorito(
            @Parameter(description = "ID del recurso educativo") @PathVariable Long resourceId,
            @Parameter(description = "ID del usuario")           @PathVariable Long userId) {
        recursoServicio.eliminarFavorito(userId, resourceId);
        return ResponseEntity.noContent().build();
    }
}
