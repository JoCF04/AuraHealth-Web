package com.aurahealth.api.auraentities;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.time.LocalDateTime;
import java.util.List;

/**
 * Entidad que representa un recurso educativo (artículo, infografía, video o guía).
 * Sustenta las épicas EP05 (Recomendaciones), EP08 (Biblioteca) y EP09 (Artículos).
 *
 * HUs cubiertas: HU04, HU07, HU09, HU15, HU23, HU29, HU30, HU33, HU34, HU37, HU41, HU42
 */
@Entity
@Table(name = "educational_resources")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class EducationalResource {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    // Título visible en las tarjetas y en la vista de detalle (HU15, HU42)
    @Column(nullable = false)
    private String title;

    // Categoría para filtrado rápido: nutrition, prevention, exercise, mental_health (HU34)
    @Column(nullable = false)
    private String category;

    // Descripción corta mostrada en las tarjetas/cards (HU15)
    @Column(columnDefinition = "TEXT")
    private String description;

    // Contenido completo del artículo para la vista de detalle (HU42)
    @Column(columnDefinition = "TEXT")
    private String content;

    // URL de la imagen de portada; el frontend usa un fallback si es null (HU15)
    @Column(name = "image_url")
    private String imageUrl;

    // Nombre del autor, visible en la lista de la biblioteca (HU23)
    private String author;

    // Tipo de formato para filtrado en la biblioteca (HU37): ARTICLE, INFOGRAPHIC, VIDEO, GUIDE
    @Enumerated(EnumType.STRING)
    @Column(name = "format_type", length = 50)
    private ResourceFormat formatType;

    // URL de descarga del PDF (HU29)
    @Column(name = "download_url")
    private String downloadUrl;

    // Flag de publicación: solo se exponen en la API los recursos con isPublished=true
    @Column(name = "is_published")
    private Boolean isPublished = Boolean.TRUE;

    @Column(name = "published_at")
    private LocalDateTime publishedAt;

    @Column(name = "created_at", updatable = false)
    private LocalDateTime createdAt;

    // Relación inversa: usuarios que guardaron este recurso como favorito (HU09)
    @OneToMany(mappedBy = "resource", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<UserFavoriteResource> favorites;

    @PrePersist
    protected void onPersist() {
        this.createdAt = LocalDateTime.now();
        if (this.publishedAt == null && Boolean.TRUE.equals(this.isPublished)) {
            this.publishedAt = LocalDateTime.now();
        }
    }
}
