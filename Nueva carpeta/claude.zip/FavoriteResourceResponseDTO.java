package com.aurahealth.api.auradtos;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.time.LocalDateTime;

/**
 * DTO de salida para la lista de artículos favoritos de un usuario.
 * Expone los datos del recurso junto con la fecha en que fue guardado.
 *
 * HU09 (EP09) — Guardar artículos en favoritos / Acceso a la lista de favoritos.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class FavoriteResourceResponseDTO {

    private Long resourceId;
    private String title;
    private String category;
    private String imageUrl;
    private String formatType;
    private LocalDateTime savedAt; // Fecha en que el usuario guardó el recurso
}
