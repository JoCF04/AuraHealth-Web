package com.aurahealth.api.aurarepositories;

import com.aurahealth.api.auraentities.DailyTip;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface DailyTipRepository extends JpaRepository<DailyTip, Long> {

    // HU04 — Obtener todos los consejos activos; el Service selecciona 3 aleatorios
    List<DailyTip> findByIsActiveTrue();
}
