package com.aurahealth.api.auraentities;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.time.LocalDateTime;

/**
 * Entidad que representa un consejo de bienestar del banner "Consejos para hoy".
 * El endpoint GET /daily-tips devuelve 3 tips aleatorios de los activos.
 *
 * HUs cubiertas: HU04 (EP05 — Visualizar banner de consejos rápidos)
 */
@Entity
@Table(name = "daily_tips")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class DailyTip {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    // Texto completo del consejo de salud
    @Column(nullable = false, columnDefinition = "TEXT")
    private String content;

    // Categoría visual: nutrition, prevention, exercise, mental_health
    private String category;

    // Solo los tips activos se devuelven al frontend
    @Column(name = "is_active")
    private Boolean isActive = Boolean.TRUE;

    @Column(name = "created_at", updatable = false)
    private LocalDateTime createdAt;

    @PrePersist
    protected void onPersist() {
        this.createdAt = LocalDateTime.now();
    }
}
