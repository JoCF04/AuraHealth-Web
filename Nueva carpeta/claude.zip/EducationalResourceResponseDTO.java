package com.aurahealth.api.auradtos;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.time.LocalDateTime;

/**
 * DTO de salida completo para la vista de detalle de un recurso educativo.
 * Usado en GET /api/v1/resources/{id} — HU42 (Acceder al detalle de la recomendación).
 * Incluye el contenido completo para lectura del artículo.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class EducationalResourceResponseDTO {

    private Long id;
    private String title;
    private String category;
    private String description;
    private String content;         // Cuerpo completo del artículo
    private String imageUrl;
    private String author;
    private String formatType;      // Representación String del enum ResourceFormat
    private String downloadUrl;
    private Boolean isPublished;
    private LocalDateTime publishedAt;
    private LocalDateTime createdAt;
}
